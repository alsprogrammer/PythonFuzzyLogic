def larsen(member_value, alfa_level):
    return member_value * alfa_level


def mamdani(member_value, alfa_level):
    return min(member_value, alfa_level)
